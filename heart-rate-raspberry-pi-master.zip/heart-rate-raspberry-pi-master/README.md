# Heart Beat sensor using Raspberry Pi and Pulse Sensors 

Setup steps are [here](http://udayankumar.com/2016/05/17/heart-beat-raspberry/)
